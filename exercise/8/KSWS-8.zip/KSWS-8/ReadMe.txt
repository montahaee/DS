Installation:
- Enzippen Sie den heruntergeladenen Ordner in ein Verzeichnis Ihrer Wahl.
- Öffnen Sie den Ordner KSWS-8 als Working Directory bzw. als obersten Ordner in einer IDE
Ihrere Wahl. 
- Öffnen Sie die Datei KSWS-8.ipynb.
- Kontrollieren Sie die in KSWS-8.ipynb angegebene Ordnerstruktur.
- Führen Sie das Jupyter Notebook von beginn an aus. 