"""
Kollektion von Codeschnipseln und Methoden der Machine Learning Übungen 
Aufgeteilt in
- Supervised Learning (Supervised)
- Unsupervised Learning (Unsupervised)
"""
